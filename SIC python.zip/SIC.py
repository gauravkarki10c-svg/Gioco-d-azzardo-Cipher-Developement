import random
import string


def get_charset():
    """
    Builds the comprehensive character list.
    Includes letters, digits, punctuation, and spaces.
    """
    return list(" abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+[]{};:'\",.<>/?\\|`~")


def shuffle_list(original_list, prng):
    """
    Fisher-Yates shuffle algorithm synced to a specific PRNG instance.
    This ensures that the shuffle is identical for anyone with the same seed.
    """
    shuffled = original_list[:]
    for i in range(len(shuffled) - 1, 0, -1):
        j = int(prng.random() * (i + 1))
        shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
    return shuffled


def process_message(text, seed_number, mode='encrypt'):
    """
    Core algorithm logic using 16 Serial Rounds and Noise Padding.
    """
    # FIXED ROUNDS: 16 (Industry standard for high security)
    ROUNDS = 16
    charset = get_charset()
    charset_len = len(charset)

    # Use the seed directly as an integer (no ord() conversion)
    base_seed = seed_number
    master_prng = random.Random(base_seed)

    result = []

    if mode == 'encrypt':
        for i, char in enumerate(text):
            # 1. NOISE PADDING
            # Adds 2-5 random 'Noise' characters before every real character.
            # This makes the cipher text look different every time.
            num_noise = master_prng.randint(2, 5)
            for _ in range(num_noise):
                result.append(random.choice(charset))

            # 2. ENCRYPT REAL CHARACTER
            # Position-based PRNG ensures 'Avalanche Effect'
            char_prng = random.Random(base_seed + i)
            current_val = char

            # 16 Serial Rounds
            for _ in range(ROUNDS):
                r_charset = shuffle_list(charset, char_prng)
                dice = char_prng.randint(1, 6)
                coin = char_prng.choice(['R', 'L'])

                if current_val in r_charset:
                    idx = r_charset.index(current_val)
                    if coin == 'R':
                        new_idx = (idx + dice) % charset_len
                    else:
                        new_idx = (idx - dice) % charset_len
                    current_val = r_charset[new_idx]

            result.append(current_val)

        # Final noise tail to hide message end
        for _ in range(master_prng.randint(2, 5)):
            result.append(random.choice(charset))

    else:  # DECRYPT MODE
        idx_in_cipher = 0
        char_count = 0

        while idx_in_cipher < len(text):
            # Skip the exact number of noise characters using the shared seed
            num_noise = master_prng.randint(2, 5)
            idx_in_cipher += num_noise

            if idx_in_cipher >= len(text):
                break

            current_val = text[idx_in_cipher]
            char_prng = random.Random(base_seed + char_count)

            # Re-generate the 16 rounds to prepare for reversal
            round_params = []
            for _ in range(ROUNDS):
                r_charset = shuffle_list(charset, char_prng)
                dice = char_prng.randint(1, 6)
                coin = char_prng.choice(['R', 'L'])
                round_params.append((r_charset, dice, coin))

            # Reverse Serial Rounds (16 down to 1)
            for r_charset, dice, coin in reversed(round_params):
                idx = r_charset.index(current_val)
                if coin == 'R':
                    new_idx = (idx - dice) % charset_len
                else:
                    new_idx = (idx + dice) % charset_len
                current_val = r_charset[new_idx]

            result.append(current_val)
            idx_in_cipher += 1
            char_count += 1

    return "".join(result)


def main():
    print("╔══════════════════════════════════════════════════════╗")
    print("║                                                      ║")
    print("║              ♦  GIOCO D'AZZARDO  ♦                   ║")
    print("║         Multi-Round Serial Cipher (16 Rounds)       ║")
    print("║                                                      ║")
    print("╚══════════════════════════════════════════════════════╝")

    while True:
        print("\n[1] Encrypt   [2] Decrypt   [3] Exit")
        choice = input("Select Option: ").strip()

        if choice == '3':
            break

        if choice in ['1', '2']:
            msg = input("Enter text: ")
            seed = input("Enter Numeric Seed (617-digit number): ").strip()

            # Validate that seed contains only digits
            if not seed.isdigit():
                print("\nError: Seed must contain only numbers (0-9)!")
                continue

            # Convert seed string to integer
            seed_number = int(seed)
            mode = 'encrypt' if choice == '1' else 'decrypt'

            try:
                output = process_message(msg, seed_number, mode)
                print(f"\n--- {mode.upper()}ED RESULT ---")
                print(output)
                if mode == 'encrypt':
                    print(f"\nLength: {len(msg)} -> {len(output)} chars")
            except Exception as e:
                print(f"\nError: Could not process. ({e})")
        else:
            print("Invalid selection.")


if __name__ == "__main__":
    main()